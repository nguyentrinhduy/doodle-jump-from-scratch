class Game {
    constructor() {
        console.log('Game created')
    }
}

new Game()
